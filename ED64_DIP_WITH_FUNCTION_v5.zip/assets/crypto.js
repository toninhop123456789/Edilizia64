
export const PASSWORD = "ed64!2025#GCM";
const PBKDF2_ITERS = 200000, KEY_LEN = 256, GCM_IV_LEN = 12, SALT_LEN = 16;
const enc = new TextEncoder(), dec = new TextDecoder();
function rnd(n){ const b=new Uint8Array(n); crypto.getRandomValues(b); return b; }
async function deriveKey(password,salt){
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2", salt, iterations:PBKDF2_ITERS, hash:"SHA-256"},
    keyMaterial, {name:"AES-GCM", length:KEY_LEN}, false, ["encrypt","decrypt"]);
}
function b64(ab){ const u=new Uint8Array(ab); let s=""; for (let i=0;i<u.length;i++) s+=String.fromCharCode(u[i]); return btoa(s) }
function ab(b64s){ const s=atob(b64s); const u=new Uint8Array(s.length); for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u.buffer }
export async function encryptText(plainText){
  const salt=rnd(SALT_LEN), iv=rnd(GCM_IV_LEN), key=await deriveKey(PASSWORD, salt);
  const ct=await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, enc.encode(plainText));
  return JSON.stringify({v:3, alg:"AES-GCM", kdf:"PBKDF2-SHA256", iters:PBKDF2_ITERS, s:b64(salt), iv:b64(iv), ct:b64(ct)});
}
export async function decryptEnvelope(envStr){
  const env = JSON.parse(envStr);
  const key = await deriveKey(PASSWORD, new Uint8Array(ab(env.s)));
  const pt = await crypto.subtle.decrypt({name:"AES-GCM", iv:new Uint8Array(ab(env.iv))}, key, new Uint8Array(ab(env.ct)));
  return dec.decode(pt);
}
